# WO-CAD-001 — Direct execution: pinned LEGION baseline vs pmix v0.16.1

**Execution:** 2026-11-10 US/Eastern (2026-11-11 UTC), Linux x86-64, Python 3.13.5, offline.

## Source and authority
- Baseline: `veraxis-protocol/LEGION-Deal-Rescue`, `main` commit `805a30b1a38772b0683cb91941da633706571b34`; `deal_rescue/industrial/cad_bom.py` blob **`d29a76dfad2b02ba9cb85831c763019c39b4858f`**, reconstructed byte-identically, validated by Git blob SHA-1.
- Candidate: `jchultarsky101/pmix` **v0.16.1**, x86_64 Linux official CI release artifact ID **10306453408**, GitHub Actions release run **34722565424**; binary SHA-256 **`cc44b80916fd03c03b74bfa5b011061583c2b96cfc0ca0685ca93cfe1ca0ae43`**, MIT license.
- Fixture archive: same release, workflow artifact ID **10306463705**, includes unmodified NIST PMI STEP AP242 test models and synthetic control files. **Important: pmix's own published test corpus, not an independently held-out sample.**
- Baseline and candidate ran **on precisely the same input bytes**. No supplier API, external model, checkout, PayPal or network call was made by the benchmark.

## Exact local results

| Metric | LEGION baseline | pmix |
|---|---:|---:|
| STEP files executed | 26 | 26 |
| Files parsed with content | 0/26 | **26/26** |
| Unknown without BOM (`Z`) | 20/26 | not applicable |
| Rejected >2MB | 6/26 | 0/26 |
| Semantic dimension records | 0 | **287** |
| GD&T tolerance records | 0 | **380** |
| Datum records | 0 | **127** |
| Extracted product records | 0 | **33** (across files, including revisions) |
| Product-use relations | 0 | **5** |
| Original STEP entity references in PMI records | 0 | **11,770**, invalid links 0 |
| Parser unknown entities | not applicable | **17 in 1 file** |
| Parser diagnostics | not applicable | **20 in 8 files** |
| Parser timings (single local run) | not applicable | p50 **54.25 ms**, p95 **214.72 ms** |
| Checks | baseline comparison recorded | **22/22 PASS** |
| Read-only LEGION adapter tests | none | **7/7 PASS** |

The 20 NIST files include earlier revisions and test cases designed to exercise PMI. The remaining 6 are synthetic control fixtures supplied with pmix. Thus 26/26 refers only to **successful parse/extraction**, **not 100% dimension recall, technical correctness, or production-file coverage**.

## Mechanism and falsification

- NIST CTC01 source entity `#120`: pmix extracted **diameter 35.0 mm** with tolerance **−0.2/+0.0 mm**. Entity `#21`: **position tolerance 0.75 mm**. The associated JSON includes exact original `source_refs`.
- Synthetic hole controls: diameter **8.0 -> 10.0 mm** and X-location **20.0 -> 25.0 mm** detected by pmix features. Equivalent inch/metric model normalized to identical geometry. Replay of NIST CTC01 output matched **byte-for-byte**.
- Negative test: malformed STEP data was rejected. Prototype adapter rejects injected unknown assembly part and never enables checkout from unverified extracted metadata.
- Assembly `assembly_two_parts.stp` -> leaf BOM `{SYN-BLOCK:1, SYN-PLATE:1}`. `assembly_properties.stp` -> `{SYN-BRACKET:1, SYN-PIN:2}`. Both have per-part original source references.

## What failed or remains unknown

**17 unsupported semantic entities:** `BASIC_ROUND_HOLE` and `BASIC_ROUND_HOLE_OCCURRENCE` in `nist_stc_09_asme1_ap242-e4.stp`; pmix explicitly reports them as not supported. They are **not silently considered verified**.

**20 diagnostics across 8 documents:** mostly `SHAPE_ASPECT` lacking geometry/datum/members and therefore not export-stable entity IDs. This weakens revision equivalence across different exporters; retain source refs and hold until independent check.

Not established: correct association of every dimension/GD&T to the right purchasable part; automatic extraction of every material and process; independent CAD/DFM and physical performance proof; 100% recall/precision; supplier inventory and quotes; live buyer consent; ZTL proof receipts; authorized commerce. A number can be **extracted** but its physical suitability is still **Z**.

## Causal verdict

**T — mechanism proven locally:** `pmix` can extract substantial structured PMI, assembly structures and geometry features from the controlled STEP corpus. The current LEGION intake cannot.

**T — isolated adapter proven:** per-leaf quantities, source refs and file digest can be carried into a provisional LEGION passport while keeping `engineering_verdict=Z`, `checkout_enabled=false`.

**Z — production engineering eligibility:** no independent verification of all critical fields and unsupported PMI elements. **NO-GO for automatic qualification, coalition admission, RFQ dispatch or PayPal.**

**GO for the next development increment:** add `pmix` behind a sandboxed, size-bounded, read-only STEP/JT parser adapter; keep legacy CSV/DXF/PDF paths; require exact drawing+part+revision+field provenance; emit `Z` for unknown or unsupported features. Validate with an independent blind test set that is not bundled in the pmix repository, including incompatible revisions/materials and quantities; require **zero unsupported `T`**, zero false orders, and complete audit receipts before integrating with supplier discovery.

## Reproduce without internet

Unzip `PAYPAL_CAD_001_EVIDENCE.zip` on Linux x86-64, then from its root:

```bash
python3 run_benchmark.py
python3 cad_adapter_prototype.py
```

Artifacts:
- `BENCHMARK_RESULTS.json`, `PER_FILE_METRICS.csv`: every input, digest, verdict, counts, runtime and per-file errors.
- `CHECKS.json`, `ADAPTER_RESULTS.json`: executable contract outcomes.
- `outputs/`: actual extracted PMI, product JSON and LEGlON proposals.
- `logs/`: stderr/stdout, negative tests and run trace.
- `tools/.../pmix`: pinned binary; `tools/pmix-0.16.1/tests/fixtures`: source input bytes; `baseline/`: byte-identical LEGION parser.
- `SHA256SUMS`: hashes for the evidence package contents.

MIT license attribution included. NIST data remains attributed to NIST; it is not an endorsement of LEGION or pmix.
