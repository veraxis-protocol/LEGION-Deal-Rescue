"""Experimental read-only pmix JSON -> LEGION intake sketch.

NOT a verified engineering interpretation, no sourcing decision, contract or payment.
This is deliberately a proof-of-mechanism adapter, not production code.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import sys

T,F,Z='T','F','Z'

def adapt(raw_step:bytes,extracted:dict,product:dict):
    h=sha256(raw_step).hexdigest()
    parts={p['id']:p for p in product.get('parts',[])}
    uses=product.get('relations',[])
    roots=product.get('roots',[]) or list(parts)
    def leaves(pid,stack=()):
        if pid in stack:raise ValueError('CYCLE_IN_ASSEMBLY')
        children=[rel['child'] for rel in uses if rel.get('parent')==pid]
        if not children:return Counter({pid:1})
        c=Counter()
        for ch in children:c.update(leaves(ch,stack+(pid,)))
        return c
    quantities=Counter()
    for root in roots:quantities.update(leaves(root))
    out=[]
    for id,qty in sorted(quantities.items()):
        p=parts.get(id)
        if not p:raise ValueError('ASSEMBLY_PART_NOT_DECLARED')
        refs=p.get('source_refs') or []
        out.append({'part_id':id,'part_no':p.get('number'),'description':p.get('name'),
                    'revision':p.get('revision'),'quantity':qty,
                    'file_sha256':h,'source_refs':refs,
                    'material':None,'process':None,'tolerances_independently_proven':False,
                    'extraction':'T' if refs else 'Z',
                    'engineering_verdict':Z,'procurement_eligible':False})
    unknown=extracted.get('unknown') or []
    return {'schema':'legion.cad-pmix-proposal/0','file_sha256':h,'parser':'pmix 0.16.1',
            'lines':out,'unmapped_pmi_entities':len(unknown),
            'unknown_entity_examples':[x.get('kind') for x in unknown[:10]],
            'engineering_verdict':Z,'supplier_verdict':Z,
            'all_lines_admitted':False,'checkout_enabled':False,'payment_effects':0,
            'evidence_scope':'PMI_PARSED_NOT_PROVEN_ENGINEERING_SUITABILITY',
            'source_ref_scheme':'STEP_P21_ENTITY_NUMBER_IN_ORIGINAL_FILE'}

def main():
    here=Path(__file__).resolve().parent
    base=here/'tools/pmix-0.16.1/tests/fixtures'
    casefiles={'two_parts':'assembly_two_parts.stp','repeated_part':'assembly_properties.stp'}
    expected={'two_parts':{'SYN-BLOCK':1,'SYN-PLATE':1},
              'repeated_part':{'SYN-BRACKET':1,'SYN-PIN':2}}
    passed=0
    for label,f in casefiles.items():
        path=base/'synthetic'/f
        i=21 if label=='two_parts' else 22
        prefix=f'{i:02d}_{Path(f).stem}'
        e=json.loads((here/'outputs'/(prefix+'_extract.json')).read_text())
        p=json.loads((here/'outputs'/(prefix+'_product.json')).read_text())
        result=adapt(path.read_bytes(),e,p)
        actual={r['part_no']:r['quantity'] for r in result['lines']}
        assert actual==expected[label],(label,actual,expected[label]);passed+=1
        assert result['engineering_verdict']==Z and result['checkout_enabled'] is False;passed+=1
        assert all(r['source_refs'] for r in result['lines']);passed+=1
        dest=here/'outputs'/('LEGION_'+label+'_ADAPTER.json')
        dest.write_text(json.dumps(result,indent=2))
        print(label,actual,'gate',result['engineering_verdict'],'checkout',result['checkout_enabled'])
    # Deliberately malformed cross-reference -> no fabricated BOM.
    corrupted=json.loads((here/'outputs'/'21_assembly_two_parts_product.json').read_text())
    corrupted['relations'][0]['child']='part:injected'
    try:adapt((base/'synthetic'/'assembly_two_parts.stp').read_bytes(),{},corrupted)
    except ValueError as exc:assert 'ASSEMBLY_PART_NOT_DECLARED' in str(exc);passed+=1
    else:raise AssertionError('FAILED_TO_BLOCK_FAKE_PART')
    print('ADAPTER_CONTRACT_TESTS',passed,'/',passed)
    (here/'ADAPTER_RESULTS.json').write_text(json.dumps({'tests_passed':passed,'tests_total':passed,'status':'T:read_only_extract,Z:engineering,Z:quote,F:checkout_enabled'},indent=2))

if __name__=='__main__':main()
