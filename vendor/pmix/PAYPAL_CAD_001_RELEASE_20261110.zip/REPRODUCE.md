# Reproduction (offline)

1. Verify the archive's `SHA256SUMS`.
2. Run `python3 run_benchmark.py` using the bundled x86-64 Linux pmix 0.16.1 binary. No Rust toolchain or network is needed.
3. Run `python3 cad_adapter_prototype.py`.
4. Inspect `BENCHMARK_RESULTS.json`, `CHECKS.json`, and `outputs/*_extract.json` for source entity references.

This experiment does not assert independent model accuracy or authorize purchases. Source provenance is pinned in `WO_CAD_001_REPORT.md`.
