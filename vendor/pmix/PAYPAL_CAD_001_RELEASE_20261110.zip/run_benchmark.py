#!/usr/bin/env python3
"""WO-CAD-001: reproducible pinned baseline vs pmix v0.16.1 experiment.
Offline only; does not contact sellers or perform purchase actions.
Expected directory: tools/pmix-0.16.1/tests/fixtures, tools/pmix-x86_64-unknown-linux-gnu/pmix,
baseline/deal_rescue/industrial/cad_bom.py
"""
from __future__ import annotations
import csv
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import time

HOME = Path(__file__).resolve().parent
FIX = HOME / "tools/pmix-0.16.1/tests/fixtures"
EXE = HOME / "tools/pmix-x86_64-unknown-linux-gnu/pmix"
SRC = HOME / "baseline/deal_rescue/industrial/cad_bom.py"
DEST = HOME / "outputs"
LOG = HOME / "logs"
for folder in (DEST,LOG): folder.mkdir(exist_ok=True,parents=True)

def sha256(b): return hashlib.sha256(b).hexdigest()
def gitblob(b): return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
def run(argv,timeout=35):
    start=time.perf_counter()
    try:
        r=subprocess.run([str(x) for x in argv],capture_output=True,text=True,timeout=timeout)
        return {"rc":r.returncode,"elapsed_ms":round((time.perf_counter()-start)*1000,3),"stderr":r.stderr[:1800],
                "stdout":r.stdout[:1200]}
    except subprocess.TimeoutExpired as exc:
        return {"rc":124,"elapsed_ms":round((time.perf_counter()-start)*1000,3),"stderr":"TIMEOUT","stdout":""}

def baseline_load():
    assert gitblob(SRC.read_bytes())=="d29a76dfad2b02ba9cb85831c763019c39b4858f", "baseline Git source mismatch"
    sp=importlib.util.spec_from_file_location("cad_bom_pinned",SRC)
    mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
    return mod

def fixtures():
    nist=sorted((FIX/"nist").glob("*.stp"))
    older=sorted((FIX/"nist"/"previous").glob("*.stp"))
    assert len(nist)>=17 and len(older)>=3, (len(nist),len(older))
    # fixed 20-file NIST set: 17 primary PMI files and 3 historical versions
    out=nist[:17]+older[:3]
    extra=[FIX/"synthetic"/x for x in (
        "assembly_two_parts.stp","assembly_properties.stp","dimension_basics.stp",
        "plate_one_hole.stp","property_basics.stp","tolerance_datum_basics.stp")]
    out+=extra
    assert len(out)==26 and len(set(map(str,out)))==26
    return out

def counts(x):
    semantic=x.get("semantic") or {}
    return {k:len(semantic.get(k) or []) for k in
            ("features","datums","datum_systems","dimensions","tolerances","notes","other")}

def pmi_ref_integrity(doc):
    # Source refs must point to entities stated by that very STEP input.
    source_refs=[]
    for arr in (doc.get("semantic") or {}).values():
        if isinstance(arr,list):
            for item in arr:
                if isinstance(item,dict):
                    source_refs.extend(item.get("source_refs") or [])
    return source_refs

def main():
    assert EXE.exists() and FIX.exists()
    m=baseline_load()
    versions=run([EXE,"--version"]);assert versions["rc"]==0 and "0.16.1" in versions["stdout"]
    rows=[];raws={}
    for i,src in enumerate(fixtures(),1):
        key=f"{i:02d}_{src.stem}"
        raw=src.read_bytes(); raws[key]=raw
        base_start=time.perf_counter()
        try:
            b=m.extract(src.name,raw)
            baseline={"status":"EXTRACTED" if b["extraction"]=="T" else "Z",
                      "reason":b["reason"],"bom_lines":len(b["bom"])}
        except Exception as exc:
            baseline={"status":"REJECTED","reason":str(exc),"bom_lines":0}
        baseline_ms=round((time.perf_counter()-base_start)*1000,3)
        ext_path=DEST/(key+"_extract.json")
        product_path=DEST/(key+"_product.json")
        ext=run([EXE,"extract",src,"--output",ext_path])
        prod=run([EXE,"product",src,"--json","--output",product_path])
        x=json.loads(ext_path.read_text()) if ext["rc"]==0 and ext_path.exists() else {}
        y=json.loads(product_path.read_text()) if prod["rc"]==0 and product_path.exists() else {}
        ct=counts(x)
        refs=pmi_ref_integrity(x)
        # Reference integrity: all referenced #N must exist in the file, but references may also include other descriptors.
        declared={int(n) for n in re.findall(rb"(?:^|\n)\s*#(\d+)\s*=",raw)}
        entity_refs=[int(r[1:]) for r in refs if isinstance(r,str) and re.fullmatch(r"#\d+",r)]
        bad_refs=sorted(set(entity_refs)-declared)
        rows.append({"case":key,"family":"NIST AP242" if "nist" in src.parts else "synthetic",
                     "filename":src.name,"size_bytes":len(raw),"sha256":sha256(raw),
                     "baseline_status":baseline["status"],"baseline_reason":baseline["reason"],
                     "baseline_bom_lines":baseline["bom_lines"],"baseline_ms":baseline_ms,
                     "pmix_extract_rc":ext["rc"],"pmix_extract_ms":ext["elapsed_ms"],
                     "pmix_extract_error":ext["stderr"],"pmix_product_rc":prod["rc"],
                     "pmix_product_ms":prod["elapsed_ms"],"pmix_product_error":prod["stderr"],
                     "pmix_parts":len(y.get("parts",[])),"pmix_relations":len(y.get("relations",[])),
                     "pmix_unknown_entities":len(x.get("unknown",[])),
                     "pmix_diagnostics":len(x.get("diagnostics",[])),"pmix_semantic_total":sum(ct.values()),
                     "pmi_source_ref_count":len(entity_refs),"invalid_pmi_source_refs":len(bad_refs),
                     **{"pmi_"+k:ct[k] for k in ct},
                     "source_path":str(src.relative_to(HOME))})
        LOG.joinpath(key+".json").write_text(json.dumps({"baseline":baseline,"pmix_extract":ext,"pmix_product":prod,"invalid_refs":bad_refs},indent=2))
        print(f"{i:02d}/26 {src.name[:43]:43} base={baseline['status']:8} PMI={sum(ct.values()):4} parts={len(y.get('parts',[])):2} pmix={ext['rc']}/{prod['rc']}", flush=True)
    # Additional exact-output and adversarial tests.
    checks=[]
    def check(name,value,details=None):
        checks.append({"name":name,"pass":bool(value),"details":details})
    spot=json.loads((DEST/"01_nist_ctc_01_asme1_ap242-e1_extract.json").read_text())
    dims=spot["semantic"]["dimensions"]
    size35=next((d for d in dims if "#120" in d.get("source_refs",[])),None)
    check("NIST CTC01 #120 size 35.0 mm", size35 and size35.get("value",{}).get("value")==35 and size35.get("value",{}).get("unit")=="mm")
    tol=(size35 or {}).get("tolerance") or {}
    check("NIST CTC01 size tolerance -0.2/0.0", tol.get("lower",{}).get("value")==-0.2 and tol.get("upper",{}).get("value")==0.0,tol)
    p=next((x for x in spot["semantic"]["tolerances"] if "#21" in x.get("source_refs",[])),None)
    check("NIST CTC01 #21 position tolerance 0.75",p and p.get("value",{}).get("value")==0.75)
    check("26 baseline runs",len(rows)==26)
    check("20 independent NIST source files",sum(r["family"]=="NIST AP242" for r in rows)==20)
    check("All baseline STEP runs no extracted BOM",all(r["baseline_bom_lines"]==0 for r in rows))
    check("PMIX parsed all STEP files",all(r["pmix_extract_rc"]==0 for r in rows))
    check("PMIX product parsed all STEP files",all(r["pmix_product_rc"]==0 for r in rows))
    check("No invalid PMI #entity references",all(r["invalid_pmi_source_refs"]==0 for r in rows))
    check("At least one NIST PMI dimension",any(r["family"]=="NIST AP242" and r["pmi_dimensions"]>0 for r in rows))
    check("At least one NIST GD&T tolerance",any(r["family"]=="NIST AP242" and r["pmi_tolerances"]>0 for r in rows))
    check("Assembly two parts parsed as multi-part",next(r for r in rows if r["filename"]=="assembly_two_parts.stp")["pmix_parts"]>=3)
    check("Max 2MB baseline rejects present",any(r["baseline_status"]=="REJECTED" for r in rows))
    # deterministic exact rerun of an NIST example, same output bytes
    before=(DEST/"01_nist_ctc_01_asme1_ap242-e1_extract.json").read_bytes()
    rereun=run([EXE,"extract",FIX/"nist"/"nist_ctc_01_asme1_ap242-e1.stp","--output",DEST/"replay_extract.json"])
    check("PMIX replay deterministic byte-for-byte",rereun["rc"]==0 and before==(DEST/"replay_extract.json").read_bytes())
    # geometry feature exact tests
    feature_data={}
    for name in ("plate_one_hole.stp","plate_hole_larger.stp","plate_hole_moved.stp","plate_one_hole_inches.stp"):
        src=FIX/"synthetic"/name
        dst=DEST/("features_"+src.stem+".json")
        proc=run([EXE,"features",src,"--json","--output",dst])
        feature_data[name]=json.loads(dst.read_text()) if proc["rc"]==0 else {}
        check("PMIX features "+name,proc["rc"]==0)
    def first_hole(filename):
        d=feature_data[filename]
        return next((f for b in d.get("bodies",[]) for f in b.get("features",[]) if f.get("kind")=="hole"),{})
    basehole=first_hole("plate_one_hole.stp")
    bigger=first_hole("plate_hole_larger.stp")
    moved=first_hole("plate_hole_moved.stp")
    inches=first_hole("plate_one_hole_inches.stp")
    check("Hole Ø8 vs changed Ø10 detected",basehole.get("diameter")==8 and bigger.get("diameter")==10)
    check("Moved hole origin 20->25 mm",basehole.get("position",[None])[0]==20 and moved.get("position",[None])[0]==25)
    check("Unit normalization inch == mm feature",bool(inches) and {k:v for k,v in inches.items() if k not in ("id","faces")}=={k:v for k,v in basehole.items() if k not in ("id","faces")})
    # malformed input: no positive extraction and no invented PMI
    corrupt=DEST/"malformed_input.stp"
    corrupt.write_bytes(b"not a STEP document")
    bad=run([EXE,"extract",corrupt,"--output",DEST/"malformed_extract.json"])
    check("Invalid STEP rejected by pmix",bad["rc"]!=0)
    # Archived source artefact hash.
    binary_hash=sha256(EXE.read_bytes())
    summary={
      "experiment":"WO-CAD-001","sample_count":len(rows),"nist_count":20,"synthetic_count":6,
      "pmix_version":"0.16.1","pmix_sha256":binary_hash,
      "pmix_parse_pass":sum(r["pmix_extract_rc"]==0 for r in rows),
      "pmix_product_pass":sum(r["pmix_product_rc"]==0 for r in rows),
      "baseline_extracted":sum(r["baseline_status"]=="EXTRACTED" for r in rows),
      "baseline_unknown":sum(r["baseline_status"]=="Z" for r in rows),
      "baseline_rejected":sum(r["baseline_status"]=="REJECTED" for r in rows),
      "pmix_dimensions":sum(r["pmi_dimensions"] for r in rows),
      "pmix_gdt_tolerances":sum(r["pmi_tolerances"] for r in rows),
      "pmix_datums":sum(r["pmi_datums"] for r in rows),
      "pmix_parts":sum(r["pmix_parts"] for r in rows),
      "pmix_relations":sum(r["pmix_relations"] for r in rows),
      "pmix_unknown_entities":sum(r["pmix_unknown_entities"] for r in rows),
      "pmix_diagnostics":sum(r["pmix_diagnostics"] for r in rows),
      "pmix_extract_p50_ms":round(statistics.median(r["pmix_extract_ms"] for r in rows),2),
      "pmix_extract_p95_ms":round(sorted(r["pmix_extract_ms"] for r in rows)[int(0.95*len(rows))-1],2),
      "checks_pass":sum(x["pass"] for x in checks),"checks_total":len(checks),
      "evidence_scope":"DIRECT LOCAL BIN+NIST CORPUS TEST; not independent manufacturing validation"}
    (HOME/"BENCHMARK_RESULTS.json").write_text(json.dumps({"summary":summary,"cases":rows,"checks":checks},indent=2,ensure_ascii=False))
    with (HOME/"PER_FILE_METRICS.csv").open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (HOME/"CHECKS.json").write_text(json.dumps(checks,indent=2))
    print("SUMMARY",json.dumps(summary,indent=2),flush=True)
    if summary["checks_pass"]!=summary["checks_total"]: sys.exit(3)
if __name__=="__main__":main()
